// Obligatorisk Oppgave  Bokregister.cpp : This file contains the 'main' function. Program execution begins and ends there.
//


#include"EBOOK.h"
#include"MAGAZINE.h"
#include"AUDIOBOOK.h"
#include"BOOKS.h"
#include"USER.h"
#include"LIBRARY.h"
#include<memory>
#include<iostream>
#include<vector>


int main()
{
    // Opprette bibliotek
    LIBRARY library;

    // Opprette noen b�ker/Lage et nytt BOOKS-objekt p� heapen
    auto book1 = std::make_shared<BOOKS>("Dune", "Frank Herbert", "Fantasy", 1965, 412);
    auto book2 = std::make_shared<BOOKS>("Ringenes Herre", "J.R.R. Tolkien", "Fantasy", 1954, 1200);
    auto book3 = std::make_shared<BOOKS>("1984", "George Orwell", "Sci-Fi", 1949, 328);
    auto book4 = std::make_shared<BOOKS>("Quo Vaidis", "Dragan", "Fag", 2025, 315);
    
    auto lydbook1 = std::make_shared<AUDIOBOOK>("Maskiner som tenker", "Str�mke", "Fag", 2022, 335, "Eriksen", 420, "MP3");
    auto lydbook2 = std::make_shared<AUDIOBOOK>("Skriket", "Fjell/Horst", "Krim", 2024, 334, "Nygaard", 482, "MP3");
    
    auto ebok1 = std::make_shared<EBOOK>("Pippi L�ngstrump", "Lindgren", "Barneb�ker", 1925, 255, 85, "PDF");
    auto ebok2 = std::make_shared<EBOOK>("Emil of L�nneberga", "Lindgren", "Barneb�ker", 1935, 285, 95, "PDF");
    
    auto magazine1 = std::make_shared<MAGAZINE>("The Time", "Time Magazine", "Fakta", 2023, 35, 9);
    auto magazine2 = std::make_shared<MAGAZINE>("Discavery", "Discavery Chanel", "Fritid", 2024, 55, 10);

    // Legge b�ker til bibliotek
    library.addBook(book1);
    library.addBook(book2);
    library.addBook(book3);
    library.addBook(book4);

    library.addBook(lydbook1);
    library.addBook(lydbook2);
    
    library.addBook(ebok1);
    library.addBook(ebok2);

    library.addBook(magazine1);
    library.addBook(magazine2);


    // Opprette brukere
    USER user1("Michal", 1);
    USER user2("Susanne", 2);
    USER user3("Marius", 3);

    // Liste over alle b�ker som er tilgjengelige i biblitek
    std::cout << "Alle tilgjengelige b�ker i biblioteket:\n";
    library.listAvailable();
    std::cout << "-------------------------\n";

    // Fjerne en bok av bibliotek
    library.removeBook(1004);

    // L�ne b�ker av biblioteket
    library.rentBook(user1, 1001);          // Michal l�ner "Dune"
    library.rentBook(user2, 1002);          // Susanne l�ner "Ringenes Herre"
    library.rentBook(user2, 1006);          // Susanne l�ner "Maskiner som tenker"
    library.rentBook(user2, 1009);          // Susanne l�ner "Emil of L�nneberga"

    // Liste over b�ker som er tilgjengelige etter utl�n.
    std::cout << "Tilgjengelige b�ker etter utl�n:\n";
    library.listAvailable();
    std::cout << "-------------------------\n";                 
    
    // Et fors�k p� � l�ne ut en utilgjengelig bok.
    std::cout << "Marius pr�ver � l�ne book2 Ringenes Herre(ISBN:1002).\n";
    try {
    library.rentBook(user3, 1002);            // Marius pr�ver � l�ne "Ringenes Herre"
    }
    catch (const std::runtime_error& e) { 
        std::cout << "Feil: " << e.what() << std::endl; 
    }
    std::cout << "-------------------------\n";                 

    // Liste over utl�nte b�ker
    std::cout << "Liste over utl�nte b�ker:\n";
    library.listUnavailable();
    std::cout << "-------------------------\n";
    
    //Reservasjon av en bok som er utl�nt                            
    std::cout << "Reservasjon av en bok som er utl�nt: \n";
    library.reserveBook(user3, 1002);                   // Marius reserverer "Ringenes Herre"
    std::cout << "-------------------------\n";
    
    // Retur av en bok som er utl�nt
    std::cout << "Return av en bok som er utl�nt: \n";
    library.returnBook(user2, 1002);                    // Susanne returnerer "Ringenes Herre"
    std::cout << "-------------------------\n";

    // Liste over b�ker som er tilgjengelige etter retu.
    std::cout << "Tilgjengelige b�ker etter retur:\n";
    library.listAvailable();
    std::cout << "-------------------------\n";

    // Rapport over mest popul�re b�ker
    std::cout << "Rapport over mest popul�re b�ker:\n";
    library.rapportPopular();
    std::cout << "-------------------------\n";
    
    // Oppdatering av b�ker
    library.updateBookInfo(1001, "Crime and punishment", "Dostojevskij", "Roman", 1866, 1200);
    library.updateBookInfo(1002, "White Nights", "Dostojevskij", "Roman", 1848, 1300);
    
    std::cout << "Book 1 etter oppdatering: ";
    book1->showInfo();
    std::cout << "Book 2 etter oppdatering: ";
    book2->showInfo();
    std::cout << "-------------------------\n";

    // Bruk av polimorfisme ved showInfo()-funksjon.
    std::cout << "Vis informasjon om subklassetittler:\n";
    lydbook1->showInfo();
    ebok1->showInfo();
    magazine1->showInfo();
    std::cout << "-------------------------\n";
   
    // Et fors�k p� � finne en bok basert p� en unik ISBN/ISSN,
    // og samtidig demonstarsjon av exception-handling.
    std::cout << "Fors�k p� � finne en bok basert p� en ISBN.\n";
    try {
    auto b = library.searchBook(1004);
    b->showInfo();
    }
    catch (const std::runtime_error& e) { 
        std::cout << "Feil: " << e.what() << std::endl; 
    }
	
    
    return 0;
}

